/*
 * audioPlay.h
 *
 *  Created on: May 20, 2022
 *      Author: Administrator
 */

#ifndef INC_AUDIOPLAY_H_
#define INC_AUDIOPLAY_H_

void PlayAudioFile(char* fileName, char* fileType);

#endif /* INC_AUDIOPLAY_H_ */
